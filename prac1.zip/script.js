// =====================
// HAMBURGER MENU
// =====================

var hamburger = document.getElementById("hamburger");
var nav = document.getElementById("nav");

hamburger.addEventListener("click", function() {
  // Toggle the 'open' class to show/hide nav on mobile
  if (nav.classList.contains("open")) {
    nav.classList.remove("open");
  } else {
    nav.classList.add("open");
  }
});


// =====================
// DARK / LIGHT THEME TOGGLE
// =====================

var themeBtn = document.getElementById("theme-btn");

themeBtn.addEventListener("click", function() {
  // Toggle dark class on body
  document.body.classList.toggle("dark");

  // Change button text based on current mode
  if (document.body.classList.contains("dark")) {
    themeBtn.textContent = "☀️ Light Mode";
  } else {
    themeBtn.textContent = "🌙 Dark Mode";
  }
});


// =====================
// MODAL POPUP
// =====================

var modalOverlay = document.getElementById("modal-overlay");
var modalTitle   = document.getElementById("modal-title");
var modalSpecs   = document.getElementById("modal-specs");
var modalClose   = document.getElementById("modal-close");

// Open modal and fill in product name + specs
function openModal(name, specs) {
  modalTitle.textContent = name;
  modalSpecs.textContent = specs;
  modalOverlay.classList.add("active");
}

// Close modal when X button is clicked
modalClose.addEventListener("click", function() {
  modalOverlay.classList.remove("active");
});

// Close modal when clicking outside the box
modalOverlay.addEventListener("click", function(e) {
  if (e.target === modalOverlay) {
    modalOverlay.classList.remove("active");
  }
});


// =====================
// FORM VALIDATION
// =====================

var bookingForm = document.getElementById("booking-form");

bookingForm.addEventListener("submit", function(e) {
  e.preventDefault(); // Stop form from refreshing the page

  var isValid = true;

  // Get field values
  var name    = document.getElementById("name").value.trim();
  var email   = document.getElementById("email").value.trim();
  var phone   = document.getElementById("phone").value.trim();
  var vehicle = document.getElementById("vehicle").value;

  // Get error span elements
  var nameError    = document.getElementById("name-error");
  var emailError   = document.getElementById("email-error");
  var phoneError   = document.getElementById("phone-error");
  var vehicleError = document.getElementById("vehicle-error");

  // Clear previous errors
  nameError.textContent    = "";
  emailError.textContent   = "";
  phoneError.textContent   = "";
  vehicleError.textContent = "";

  // Check: Name must not be empty
  if (name === "") {
    nameError.textContent = "Please enter your name.";
    isValid = false;
  }

  // Check: Email must have @ and a dot
  if (email === "") {
    emailError.textContent = "Please enter your email.";
    isValid = false;
  } else if (email.indexOf("@") === -1 || email.indexOf(".") === -1) {
    emailError.textContent = "Please enter a valid email.";
    isValid = false;
  }

  // Check: Phone must be at least 10 digits
  if (phone === "") {
    phoneError.textContent = "Please enter your phone number.";
    isValid = false;
  } else if (phone.length < 10) {
    phoneError.textContent = "Phone number seems too short.";
    isValid = false;
  }

  // Check: A vehicle must be selected
  if (vehicle === "") {
    vehicleError.textContent = "Please select a vehicle.";
    isValid = false;
  }

  // If all fields are valid, show a success message
  if (isValid) {
    alert("Thank you, " + name + "! Your test ride for " + vehicle + " has been booked.");
    bookingForm.reset(); // Clear the form
  }
});


// =====================
// REAL-TIME VALIDATION (while typing)
// =====================

// Clear name error as soon as user types something
document.getElementById("name").addEventListener("input", function() {
  if (this.value.trim() !== "") {
    document.getElementById("name-error").textContent = "";
  }
});

// Clear email error as soon as it looks valid
document.getElementById("email").addEventListener("input", function() {
  var val = this.value.trim();
  if (val.indexOf("@") !== -1 && val.indexOf(".") !== -1) {
    document.getElementById("email-error").textContent = "";
  }
});

// Clear phone error once 10+ characters entered
document.getElementById("phone").addEventListener("input", function() {
  if (this.value.trim().length >= 10) {
    document.getElementById("phone-error").textContent = "";
  }
});

// Clear vehicle error when a selection is made
document.getElementById("vehicle").addEventListener("change", function() {
  if (this.value !== "") {
    document.getElementById("vehicle-error").textContent = "";
  }
});
